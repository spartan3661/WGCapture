from .core import capture_screen

__all__ = ["capture_screen"]